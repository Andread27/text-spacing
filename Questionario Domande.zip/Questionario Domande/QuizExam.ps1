# Define question types
enum QuestionType {
    SingleChoice
    MultipleChoice
    DragAndDrop
} 

class Question {
    [string]$Text
    [QuestionType]$Type
    [string[]]$Options
    [object]$CorrectAnswers
    [int]$Points

    Question ($text, $type, $options, $correctAnswer, $points) {
        $this.Text              = $text
        $this.Type              = $type
        $this.Options           = $options
        $this.CorrectAnswers    = $correctAnswer
        $this.Points            = $points
    }
}

# Function to display a question
function ShowQuestion {
    param (
        [Question]$question,
        [int]$questionNumber
    )

    Write-Host "`n`n`n" -ForegroundColor Yellow
    
    Write-Host "($questionNumber) $($question.Text)`n" -ForegroundColor White

    # Randomize options and create letter mapping
    $random = New-Object System.Random
    $shuffledOptions = $question.Options | Sort-Object { $random.Next() }
    $letterMapping = @{}
    $letters = 'A','B','C','D','E','F','G','H','I','J'

    for ($i = 0; $i -lt $shuffledOptions.Count; $i++) {
        $letter = $letters[$i]
        $letterMapping[$letter] = $shuffledOptions[$i]
        Write-Host "[$letter] $($shuffledOptions[$i])" -ForegroundColor Yellow
    }

    Write-Host ""
    return $letterMapping
}
function GetUserAnswer {
    param (
        [Question]$question,
        [hashtable]$letterMapping
    )

    $answer = $null
    $letters = @()

    switch ($question.Type.ToString()) {
        "SingleChoice" {
            do {
                $answer = Read-Host "Inserisci la lettera della risposta corretta (es. A)"
                $answer = $answer.Trim().ToUpper()
                if (-not $letterMapping.ContainsKey($answer)) {
                    Write-Host "Lettera non valida! Inserisci una lettera tra A e J." -ForegroundColor Red
                }
            } while (-not $letterMapping.ContainsKey($answer))
            return $answer
        }

        "MultipleChoice" {
            $correctCount = $question.CorrectAnswers.Count
            Write-Host "Questa domanda ha $correctCount risposta/e corretta/e." -ForegroundColor Cyan

            do {
                $answer = Read-Host "Inserisci le lettere delle risposte corrette separate da virgola (es. A,B,C)"
                $letters = $answer -split ',' | ForEach-Object { $_.Trim().ToUpper() }
                $invalid = $letters | Where-Object { $_ -notmatch '^[A-J]$' -or -not $letterMapping.ContainsKey($_) }
                if ($invalid.Count -gt 0) {
                    Write-Host "Lettere non valide! Inserisci lettere tra A e J separate da virgola." -ForegroundColor Red
                }
            } while ($invalid.Count -gt 0)
            return $letters
        }

        "DragAndDrop" {

            Write-Host "Questa domanda e' DRAG-AND-DROP. Inserire tutte le lettere nell'ordine corretto." -ForegroundColor Cyan
            do {
                $answer = Read-Host "Inserisci le lettere nell'ordine corretto separate da virgola (es. D,A,B,C)"
                $letters = $answer -split ',' | ForEach-Object { $_.Trim().ToUpper() }
                $invalid = $letters | Where-Object { $_ -notmatch '^[A-J]$' -or -not $letterMapping.ContainsKey($_) }
                if ($invalid.Count -gt 0 -or $letters.Count -ne $question.Options.Count) {
                    Write-Host "Lettere non valide! Inserisci tutte le lettere tra A e J nell'ordine corretto." -ForegroundColor Red
                }
            } while ($invalid.Count -gt 0 -or $letters.Count -ne $question.Options.Count)
            return $letters
        }
    }
}function CheckAnswer {
    param (
        [Question]$question,
        $userAnswer,
        [hashtable]$letterMapping
    )

    switch ($question.Type.ToString()) {
        "SingleChoice" {
            # Confronto diretto tra la risposta utente e la risposta corretta (entrambi singole stringhe)
            $selectedValue = $letterMapping[$userAnswer]
            return $selectedValue -eq $question.CorrectAnswers[0]
        }

        "MultipleChoice" {
            # Mappatura delle lettere alle opzioni, rimozione duplicati e ordinamento
            $userValues = $userAnswer | ForEach-Object { $letterMapping[$_] } | Sort-Object -Unique
            $correctValues = $question.CorrectAnswers | Sort-Object

            return ($userValues -join ',') -eq ($correctValues -join ',')
        }

        "DragAndDrop" {
            # L'ordine conta, quindi niente sort, ma confronto sequenziale
            $userValues = $userAnswer | ForEach-Object { $letterMapping[$_] }

            return ($userValues -join ',') -eq ($question.CorrectAnswers -join ',')
        }
    }

    return $false
}



function LoadQuestions {
    $questionsFile = Join-Path $PSScriptRoot "Questions.json"
    if (Test-Path $questionsFile) {
        $questionsData = Get-Content $questionsFile | ConvertFrom-Json
        return $questionsData.questions
    } else {
        Write-Host "File delle domande non trovato: $questionsFile" -ForegroundColor Red
        return @()
    }
}

function StartQuiz {

    Clear-Host
    $questionData = LoadQuestions
    $questions = @()
    foreach ($q in $questionData) {
        $type = [QuestionType]$q.Type
        $question = [Question]::new($q.Text, $type, $q.Options, $q.CorrectAnswers, $q.Points)
        $questions += $question
    }

    Write-Host "Benvenuto nel quiz di preparazione per Sentry-CPC" -ForegroundColor Blue

    if ($questions.Count -eq 0) {
        Write-Host "Nessuna domanda trovata! Aggiungi prima delle domande." -ForegroundColor Red
        return
    }

    if ($questions.Count -lt 40) {
        Write-Host "Attenzione: Ci sono meno di 40 domande disponibili!" -ForegroundColor Yellow
        Write-Host "Verranno utilizzate tutte le domande disponibili: $($questions.Count)." -ForegroundColor Yellow
        $totalQuestions = $questions.Count
    } else {
        $totalQuestions = 40
        Write-Host "Sono disponibili nel pool $($questions.Count) domande." -ForegroundColor Blue
        Write-Host "Il quiz utilizzera' 40 domande prese a caso da quelle presenti" -ForegroundColor Blue


    }

    $score = 0
    $totalPoints = 0
    $usedQuestions = @{}
    $currentQuestion = 1

    for ($i = 0; $i -lt $totalQuestions; $i++) {
        $question = $null
        while ($null -eq $question -or $usedQuestions.ContainsKey($question.Text)) {
            $question = $questions | Get-Random
        }
        $usedQuestions[$question.Text] = $true

        $letterMapping = ShowQuestion -question $question -questionNumber $currentQuestion
        $userAnswer = GetUserAnswer -question $question -letterMapping $letterMapping

        if (CheckAnswer -question $question -userAnswer $userAnswer -letterMapping $letterMapping) {
            Write-Host "Corretto!" -ForegroundColor Green
            $score += $question.Points
        } else {
            Write-Host "Sbagliato!" -ForegroundColor Red
            switch ($question.Type.ToString()) {
                "SingleChoice" {
                    Write-Host "Risposta corretta: $($question.CorrectAnswers)" -ForegroundColor Yellow
                }
                "MultipleChoice" {
                    Write-Host "Risposte corrette: $($question.CorrectAnswers -join ', ')" -ForegroundColor Yellow
                }
                "DragAndDrop" {
                    Write-Host "Ordine corretto: $($question.CorrectAnswers -join ' -> ')" -ForegroundColor Yellow
                }
            }
        }

        $totalPoints += $question.Points
        $currentQuestion++
        Start-Sleep -Seconds 1
    }

    $percentage = [math]::Round($score / $totalPoints * 100, 2)
    Write-Host "`nQuiz Completato!" -ForegroundColor Cyan
    Write-Host "Punteggio totale: $($score) su $($totalPoints) punti" -ForegroundColor Yellow
    Write-Host "Percentuale di successo: $($percentage)%" -ForegroundColor Green

    if ($percentage -ge 70) {
        Write-Host "COMPLIMENTI! HAI SUPERATO IL QUIZ" -ForegroundColor Green
    } else {
        Write-Host "PUNTEGGIO INSUFFICIENTE! IL QUIZ NON E' STATO SUPERATO." -ForegroundColor Red
        Write-Host "E' NECESSARIO UN MINIMO DI 70% DI SUCCESSO." -ForegroundColor Red
    }
}

# Start the quiz
StartQuiz
