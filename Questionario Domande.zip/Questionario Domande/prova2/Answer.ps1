function New-Answer {
    param(
        [bool]$IsCorrect,
        [bool]$IsOrder,
        [string]$Value,
        [int]$Order
    )

    return [PSCustomObject]@{
        IsCorrect       = $IsCorrect
        IsOrder         = $IsOrder
        Value           = $Value
        Order           = $Order
        ShuffledLetter  = ""
    }
}
