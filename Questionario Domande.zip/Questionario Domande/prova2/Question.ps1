function New-Question {
    param(
        [string]$Text,
        [array]$Answers,
        [int]$NumCorrectAnswers
    )

    return [PSCustomObject]@{
        Text             = $Text
        Answers          = $Answers
        NumCorrectAnswers= $NumCorrectAnswers
        ShuffledOptions  = @()
    }
}

function Shuffle-Options {
    param($Question)

    $shuffled = $Question.Answers | Get-Random -Count $Question.Answers.Count
    $letter = [char]65  # 'A'
    $options = @()

    foreach ($answer in $shuffled) {
        $answer.ShuffledLetter = [string]$letter
        $options += "$letter) $($answer.Value)"
        $letter++
    }

    $Question.ShuffledOptions = $options
}

function Is-Correct {
    param($Question, $UserAnswers)

    $answers = $Question.Answers

    if ($answers[0].IsOrder) {
        $ordered = $answers | Sort-Object Order
        if ($UserAnswers.Count -ne $Question.NumCorrectAnswers) {
            return $false
        }

        for ($i = 0; $i -lt $UserAnswers.Count; $i++) {
            if ($UserAnswers[$i] -ne $ordered[$i].ShuffledLetter) {
                return $false
            }
        }

        return $true
    } else {
        $correctCount = 0
        foreach ($userAnswer in $UserAnswers) {
            foreach ($answer in $answers) {
                if ($userAnswer -eq $answer.ShuffledLetter -and $answer.IsCorrect) {
                    $correctCount++
                }
            }
        }

        return $correctCount -eq $Question.NumCorrectAnswers
    }
}

function Get-CorrectAnswers {
    param($Question)

    $correct = @()
    foreach ($answer in $Question.Answers) {
        if ($answer.IsCorrect -or $answer.IsOrder) {
            $correct += "$($answer.ShuffledLetter)) $($answer.Value)"
        }
    }

    return ($correct -join ", ")
}
