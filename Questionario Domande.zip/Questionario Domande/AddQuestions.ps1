# Percorso del file JSON
$jsonPath = Join-Path $PSScriptRoot "Questions.json"

# Carica il file esistente o crea nuovo
if (Test-Path $jsonPath) {
    $jsonContent = Get-Content $jsonPath -Raw | ConvertFrom-Json
} else {
    $jsonContent = [PSCustomObject]@{ questions = @() }
}


Clear-Host
# Mappa tipi di domanda
$typeMap = @{
    '1' = 'SingleChoice'
    '2' = 'MultipleChoice'
    '3' = 'DragAndDrop'
}

do {
    Write-Host "`n--- Aggiunta Nuova Domanda ---" -ForegroundColor Cyan

    # Testo della domanda
    $text = Read-Host "Inserisci il testo della domanda"

    # Verifica duplicati
    $existingQuestion = $jsonContent.questions | Where-Object { $_.text -eq $text }
    if ($existingQuestion) {
        Write-Host "La domanda esiste gia'." -ForegroundColor Yellow
        $action = Read-Host "Vuoi sostituirla? (S per continuare, qualsiasi altro tasto per skippare)"
        if ($action -ne "S") {
            continue
        } else {
            $jsonContent.questions = $jsonContent.questions | Where-Object { $_.text -ne $text }
        }
    }

    # Tipo domanda interattivo
    Write-Host "`nScegli il tipo di domanda:"
    Write-Host "1 - SingleChoice"
    Write-Host "2 - MultipleChoice"
    Write-Host "3 - DragAndDrop"
    do {
        $typeChoice = Read-Host "Digita 1, 2 o 3"
    } while (-not $typeMap.ContainsKey($typeChoice))
    $type = $typeMap[$typeChoice]

    # Opzioni
    $options = @()
    Write-Host "`nInserisci le opzioni (minimo 2, digita una per riga, lascia vuoto per terminare):"
    while ($true) {
        $opt = Read-Host "Opzione"
        if ([string]::IsNullOrWhiteSpace($opt)) {
            if ($options.Count -lt 2) {
                Write-Host "Servono almeno 2 opzioni." -ForegroundColor Red
                continue
            }
            break
        }
        $options += $opt
    }

    # Risposte corrette
    $correctAnswers = @()
    Write-Host "`nInserisci le risposte corrette (devono essere tra le opzioni fornite)"
    if ($type -eq "SingleChoice") {
        do {
            $correct = Read-Host "Inserisci la risposta corretta"
            if ($correct -in $options) {
                $correctAnswers = @($correct)
            } else {
                Write-Host "La risposta '$correct' non e' tra le opzioni!" -ForegroundColor Red
            }
        } while ($correctAnswers.Count -eq 0)
    } else {
        while ($true) {
            $corr = Read-Host "Risposta corretta (lascia vuoto per terminare)"
            if ([string]::IsNullOrWhiteSpace($corr)) {
                if ($correctAnswers.Count -eq 0) {
                    Write-Host "Inserisci almeno una risposta corretta." -ForegroundColor Red
                    continue
                }
                break
            }
            if ($corr -in $options) {
                $correctAnswers += $corr
            } else {
                Write-Host "'$corr' non e' un'opzione valida!" -ForegroundColor Red
            }
        }
    }

    # Punteggio
    do {
        $points = Read-Host "Quanti punti vale la domanda?"
    } while (-not ($points -as [int]))

    # Crea oggetto domanda
    $newQuestion = [PSCustomObject]@{
        text           = $text
        type           = $type
        options        = $options
        correctAnswers = $correctAnswers
        points         = [int]$points
    }

    # Aggiunge la domanda
    $jsonContent.questions += $newQuestion

    $more = Read-Host "`nVuoi aggiungere un'altra domanda? (S per continuare)"
} while ($more -eq "S")

# Salva il file
$jsonContent | ConvertTo-Json -Depth 5 | Set-Content -Encoding UTF8 -Path $jsonPath

Write-Host "`nDomande salvate correttamente in '$jsonPath'." -ForegroundColor Green
