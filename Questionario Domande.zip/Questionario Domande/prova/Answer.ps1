class Answer {

    [bool]$IsCorrect
    [bool]$IsOrder
    [string]$Value
    [int]$Order
    [string]$ShuffledOptions


    Answer ([bool]$iscor, [bool]$isord, [string]$txt, [int]$ord) {
        this.IsCorrect = $iscor
        this.IsOrder = $isord
        this.Value = $txt
        this.Order = $ord
    }

    [void]SetShuffledLetter([string]$Letter) {
        $this.ShuffledOptions = $Letter
    }
}
