$global:ScriptLocation = Split-Path -Parent $MyInvocation.MyCommand.Path

. "$ScriptLocation\Answer.ps1"
. "$ScriptLocation\QuestionPool.ps1"
. "$ScriptLocation\Question.ps1"


Clear-Host
Write-Host "`nBenvenuto al test di preparazione al Defender - PAM!"
Write-Host "`nPer superare il test occorre ottenere un punteggio di almeno 70%`n"



$questionPool = Get-QuestionPool
$numQuestions = 1

if ($questionPool.Count -eq 0) {
    Write-Host "`nNumero di domande non valido. Uscita dal programma.`n"
    exit
}

# if ($numQuestions -lt 1 -or $numQuestions -gt $questionPool.Count) {
#     Write-Host "`nNumero di domande non valido. Uscita dal programma.`n"
#     exit
# }

Write-Host "`nIl test conterra' $numQuestions domande scelte casualmente dal pool di $($questionPool.Count) domande.`n"

#$selectedQuestions = $questionPool | Get-Random -Count $numQuestions

$selectedQuestions = $questionPool 
$correctAnswers = 0

$ao = $selectedQuestions.Count
Write-Host "allora $ao "

for ($i = 0; $i -lt $questionPool.Count; $i++) {
    $question = $selectedQuestions[$i]
    Shuffle-Options -Question $question

    Write-Host "`nDomanda $($i + 1):`n"
    Write-Host "$($question.Text)`n"

    foreach ($opt in $question.ShuffledOptions) {
        Write-Host "$opt`n"
    }

    $input = Read-Host "Inserisci la tua risposta (se più risposte, separale con virgola)"
    $userAnswers = $input.ToUpper().Split(',').Trim()

    if (Is-Correct -Question $question -UserAnswers $userAnswers) {
        Write-Host "`nCorretto!"
        $correctAnswers++
    } else {
        $correct = Get-CorrectAnswers -Question $question
        Write-Host "`nErrore! La risposta corretta era: $correct`n"
        Start-Sleep -Seconds 1
    }

    Start-Sleep -Seconds 1
}

Write-Host "`nQuiz completato!`n"
$successRate = [math]::Round(($correctAnswers / $numQuestions) * 100, 2)
Write-Host "`nHai risposto correttamente a $correctAnswers su $numQuestions."
Write-Host "Hai ottenuto il $successRate% del punteggio.`n"

if ($successRate -ge 70) {
    Write-Host "`nComplimenti! Hai superato il test!`n"
} else {
    Write-Host "`nMi dispiace! Non hai superato il test.`n"
}
