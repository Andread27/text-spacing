function Get-QuestionPool {
    # Sostituisci questo contenuto con domande reali prese da QuestionPool.java
    $questions = @()

    # Esempio fittizio
    $answers = @(
        New-Answer -IsCorrect $true -IsOrder $false -Value "Risposta Corretta" -Order 1
        New-Answer -IsCorrect $false -IsOrder $false -Value "Risposta Sbagliata" -Order 2
    )

    $questions += New-Question -Text "Domanda esempio?" -Answers $answers -NumCorrectAnswers 1

    return $questions
}
