$global:ScriptLocation = Split-Path -Parent $MyInvocation.MyCommand.Path
. "$ScriptLocation\Answer.ps1"

class Question {
    [int]$CorrectAnswers
    [string]$Text
    $Answers
    [string[]]$ShuffledOptions

    # Costruttore
    Question([string]$txt, $answers, [int]$numansw) {
        $this.Text = $txt
        $this.Answers = $answers
        $this.CorrectAnswers = $numansw
        $this.ShuffledOptions = @()
    }
}

function ShuffleOptions {
    param($Question)

    $shuffled = $Question.Answers | Get-Random -Count $Question.Answers.Count
    $letter = [char]65  # 'A'
    $options = @()

    foreach ($answer in $shuffled) {
        $answer.SetShuffledLetter([string]$letter)
        $options += "$letter) $($answer.Value)"
        $letter++
    }

    $Question.ShuffledOptions = $options
}

# Creazione risposte
$answer1 = [Answer]::new($false, $false,"33", 0)


$answer2 = [Answer]::new($true, $false,"35", 0)


$answer3 = [Answer]::new($false, $false,"40", 0)


$answer4 = [Answer]::new($false, $false,"15", 0)


# Assegnazione risposte a un array
$answer = @($answer1, $answer2, $answer3, $answer4)

# Testo domanda
$txt = "Quanto fa 15 + 18?"

# Numero risposte corrette
$numansw = 1

# Creazione oggetto Question
$Question = [Question]::new($txt, $answer, $numansw)

# Shuffle
ShuffleOptions -Question $Question

# Visualizza le opzioni
$Question.ShuffledOptions

# Visualizza la domanda
Write-Host "Domanda: $($Question.Text)"
Write-Host ""

# Visualizza le opzioni mescolate
foreach ($opt in $Question.ShuffledOptions) {
    Write-Host $opt
}
