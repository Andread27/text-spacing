#######################################################################
#
#                Sample Package for PSM Deploy Connectors
#
# August 2018
# CyberArk Software Ltd.
#######################################################################


This is a sample VNC connector.
Use this sample as a reference when creating your universal connector package.

Deploying this sample package will add the PSMRealVNCDispatcherSample connector to the Components\Connectors directory
under the PSM installation path. (Default: C:\Program Files (x86)\CyberArk\PSM\Components\Connectors) 
The PSM-VNCClientSample-AutoDeployed connection component is already configured to launch this connector application.

#######################################################################


Automatically deploying a universal connector on the PSM machines:
=================================================================

1. Install the connection client you want to integrate on the PSM machine 
   (In this sample we assume its the VNC Viewer app, located in C:\VNC-Viewer-5.0.5-Windows-64bit.exe)

2. Create a zip archive file containing:

   - The universal connector executable you created in the step above

   - Any additional files needed for the universal connector to run, such as .dlls or .exes.

   - A package.json file
     To enable the universal connector to run on the PSM machine, specify each application run by the 
     universal connector in the package.json.

     NOTE: The package.json file must appear at the root of the zip archive

   - The PSMDispatcherUtils.dll file.
     Copy it from the PSM\Components folder, Default: C:\Program Files (x86)\CyberArk\PSM\Components

3. Upload the package to the PSMUniversalConnectors safe

4. Restart CyberArk Privileged Session Manager service

   






