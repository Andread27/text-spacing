#cs ----------------------------------------------------------------------------

 AutoIt Version: 3.3.16.1
 Author:         AndreaDonelli

 Script Function:
	Template AutoIt script.

#ce ----------------------------------------------------------------------------

Local $dbName, $Username, $Passwd, $SQLDevPath

$dbName = "Oracle Database Demo"
$Username = "SYS"
$Passwd = "123"
$SQLDevPath = "C:\sqldeveloper.exe"

AutologSQLDev ($SQLDevPath, $dbName, $Username, $Passwd )

Func AutologSQLDev ($Path, $NameDB, $Usrn, $Pswd )

	; Run SQL Developer App
	Run ('"' & $Path & '"')

	; Wait for it to open
	WinWaitActive ("Oracle SQL Developer")
	FiveSec()

	; Add a new Database connection
	Send ("!{F10}")
	FiveSec()
	Send ("{ENTER}")
	FiveSec()

	; Add the name of database
	Send($NameDB)
	Msec()

	; Add the Username
	Send("!u")
	Msec()
	Send($Usrn)
	Msec()

	; Select the Rule "SYSDBA"
	send("{TAB}")
	Msec()
	Send("{DOWN 2}")
	Msec()
	Send("{ENTER}")
	Msec()

	; Add the Password
	Send("!p")
	Msec()
	Send($Pswd)
	Msec()

	; Save the Password for future login
	Send("!v")
	Msec()

	; Connect to the database
	Send("!o")
	FiveSec()

	; Save the configuration
	Send("{TAB 3}")
	Send("{ENTER}")
	FiveSec()

EndFunc

Func TenSec()
	Sleep(10000)
EndFunc

Func Msec()
	Sleep(800)
EndFunc

Func FiveSec()
	Sleep(5000)
EndFunc

