#AutoIt3Wrapper_UseX64=Y
Opt("MustDeclareVars", 1)
AutoItSetOption("WinTitleMatchMode", 3) ; EXACT_MATCH!

;============================================================
;             PSM AutoIt Dispatcher - SQL Developer
;             ---------------------------------------
;
; Connection component per Oracle SQL Developer.
; L'host di destinazione viene preso dal parametro
; Remote Machine della sessione; se assente si usa
; l'Address dell'account.
;
; Basato su PSMAutoItDispatcherSkeleton.au3
; Cyber-Ark Software Ltd.
;============================================================
#include "PSMGenericClientWrapper.au3"

;=======================================
; Consts & Globals
;=======================================
Global Const $DISPATCHER_NAME       = "SQLDeveloper"
Global Const $CLIENT_EXECUTABLE     = "C:\sqldeveloper.exe" ; CHANGE_ME - percorso portable
Global Const $ERROR_MESSAGE_TITLE   = "PSM " & $DISPATCHER_NAME & " Dispatcher error message"
Global Const $LOG_MESSAGE_PREFIX    = $DISPATCHER_NAME & " Dispatcher - "

; Titolo finestra principale di SQL Developer
Global Const $MAIN_WINDOW_TITLE     = "Oracle SQL Developer"
; Titolo della dialog di creazione connessione
Global Const $CONN_DIALOG_TITLE     = "New / Select Database Connection"

; Timeout (millisecondi)
Global Const $APP_START_TIMEOUT     = 120000
Global Const $DIALOG_TIMEOUT        = 60000

; Ritardi di digitazione
Global Const $DELAY_SHORT           = 800
Global Const $DELAY_LONG            = 5000

; Numero di TAB per passare da Role a Hostname ; CHANGE_ME se necessario
Global Const $TABS_ROLE_TO_HOSTNAME = 2

Global $TargetUsername
Global $TargetPassword
Global $TargetAddress
Global $TargetDatabase
Global $TargetPort
Global $TargetRole
Global $RemoteMachine
Global $EffectiveHost
Global $ConnectionName
Global $ConnectionClientPID = 0

;=======================================
; Code
;=======================================
Exit Main()

;=======================================
; Main
;=======================================
Func Main()

	; Init PSM Dispatcher utils wrapper
	ToolTip("Initializing...")
	If (PSMGenericClient_Init() <> $PSM_ERROR_SUCCESS) Then
		Error(PSMGenericClient_PSMGetLastErrorString())
	EndIf

	LogWrite("successfully initialized Dispatcher Utils Wrapper")

	; Get the dispatcher parameters
	FetchSessionProperties()

	; Determina l'host effettivo
	ResolveTargetHost()

	LogWrite("mapping local drives")
	If (PSMGenericClient_MapTSDrives() <> $PSM_ERROR_SUCCESS) Then
		Error(PSMGenericClient_PSMGetLastErrorString())
	EndIf

	LogWrite("starting client application")
	ToolTip("Starting " & $DISPATCHER_NAME & "...")
	$ConnectionClientPID = Run('"' & $CLIENT_EXECUTABLE & '"')
	If ($ConnectionClientPID == 0) Then
		Error(StringFormat("Failed to execute process [%s]", $CLIENT_EXECUTABLE, @error))
	EndIf

	; ------------------
	; Handle login here!
	; ------------------
	HandleLogin()

	; Send PID to PSM so recording/monitoring can begin
	; Notice that until we send the PID, PSM blocks all user input.
	LogWrite("sending PID to PSM")
	If (PSMGenericClient_SendPID($ConnectionClientPID) <> $PSM_ERROR_SUCCESS) Then
		Error(PSMGenericClient_PSMGetLastErrorString())
	EndIf

	; Terminate PSM Dispatcher utils wrapper
	LogWrite("Terminating Dispatcher Utils Wrapper")
	PSMGenericClient_Term()

	Return $PSM_ERROR_SUCCESS
EndFunc   ;==>Main

;==================================
; Functions
;==================================

; #FUNCTION# ====================================================================================================================
; Name...........: FetchSessionProperties
; Description ...: Fetches properties required for the session
; ===============================================================================================================================
Func FetchSessionProperties()

	If (PSMGenericClient_GetSessionProperty("Username", $TargetUsername) <> $PSM_ERROR_SUCCESS) Then
		Error(PSMGenericClient_PSMGetLastErrorString())
	EndIf

	If (PSMGenericClient_GetSessionProperty("Password", $TargetPassword) <> $PSM_ERROR_SUCCESS) Then
		Error(PSMGenericClient_PSMGetLastErrorString())
	EndIf

	If (PSMGenericClient_GetSessionProperty("Address", $TargetAddress) <> $PSM_ERROR_SUCCESS) Then
		Error(PSMGenericClient_PSMGetLastErrorString())
	EndIf

	; Proprieta' opzionali: l'assenza non deve interrompere la sessione
	PSMGenericClient_GetSessionProperty("Database", $TargetDatabase)
	PSMGenericClient_GetSessionProperty("Port", $TargetPort)
	PSMGenericClient_GetSessionProperty("Role", $TargetRole)

	; Parametro Remote Machine
	PSMGenericClient_GetSessionProperty("PSMRemoteMachine", $RemoteMachine)
	If StringStripWS($RemoteMachine, 8) = "" Then
		PSMGenericClient_GetSessionProperty("RemoteMachine", $RemoteMachine)
	EndIf

	If StringStripWS($TargetPort, 8) = "" Then $TargetPort = "1521"

	LogWrite("properties fetched - address=[" & $TargetAddress & "] db=[" & $TargetDatabase & _
			"] port=[" & $TargetPort & "] role=[" & $TargetRole & "] remote=[" & $RemoteMachine & "]")

EndFunc   ;==>FetchSessionProperties

; #FUNCTION# ====================================================================================================================
; Name...........: ResolveTargetHost
; Description ...: Sceglie l'host: Remote Machine se valorizzata, altrimenti Address
; ===============================================================================================================================
Func ResolveTargetHost()

	If StringStripWS($RemoteMachine, 8) <> "" Then
		$EffectiveHost = StringStripWS($RemoteMachine, 3)
		LogWrite("target host taken from remote machine: " & $EffectiveHost)
	Else
		$EffectiveHost = StringStripWS($TargetAddress, 3)
		LogWrite("target host taken from account address: " & $EffectiveHost)
	EndIf

	If $EffectiveHost = "" Then
		Error("Nessun host disponibile: Address e Remote Machine sono entrambi vuoti")
	EndIf

	$ConnectionName = $TargetDatabase & "_" & $EffectiveHost

EndFunc   ;==>ResolveTargetHost

; #FUNCTION# ====================================================================================================================
; Name...........: HandleLogin
; Description ...: Crea la connessione nella GUI di SQL Developer e si collega
; ===============================================================================================================================
Func HandleLogin()

	; Attesa della finestra principale
	If WinWait($MAIN_WINDOW_TITLE, "", $APP_START_TIMEOUT / 1000) = 0 Then
		Error("Timeout in attesa della finestra principale di SQL Developer")
	EndIf

	WinActivate($MAIN_WINDOW_TITLE)
	WinWaitActive($MAIN_WINDOW_TITLE, "", 30)
	LogWrite("main window is active")
	Sleep($DELAY_LONG)

	; Apertura della dialog: menu contestuale sul nodo Connections -> New Connection
	Send("!{F10}")
	Sleep($DELAY_SHORT)
	Send("{ENTER}")
	Sleep($DELAY_LONG)

	LogWrite("new connection dialog requested")

	; Nome connessione (il focus e' gia' sul campo Name)
	Send($ConnectionName)
	Sleep($DELAY_SHORT)

	; Username
	Send("!u")
	Sleep($DELAY_SHORT)
	Send($TargetUsername, 1)
	Sleep($DELAY_SHORT)

	; Password
	Send("!p")
	Sleep($DELAY_SHORT)
	Send($TargetPassword, 1)
	Sleep($DELAY_SHORT)

	; Ruolo: selezione dalla combo se valorizzato
	If StringStripWS($TargetRole, 8) <> "" Then
		SelectRole($TargetRole)
	EndIf

	; Hostname
	Send("!h")
	Sleep($DELAY_SHORT)
	Send("^a")
	Send($EffectiveHost, 1)
	Sleep($DELAY_SHORT)

	; Porta
	Send("!r")
	Sleep($DELAY_SHORT)
	Send("^a")
	Send($TargetPort, 1)
	Sleep($DELAY_SHORT)

	; Service name (radio + campo)
	Send("!v")
	Sleep($DELAY_SHORT)
	Send("^a")
	Send($TargetDatabase, 1)
	Sleep($DELAY_SHORT)

	LogWrite("connection fields populated - host=" & $EffectiveHost & " port=" & $TargetPort)

	; Connect
	Send("!o")
	Sleep($DELAY_LONG)

	; Pulizia della password dalla memoria dello script
	$TargetPassword = ""

	LogWrite("connect issued")

EndFunc   ;==>HandleLogin

; #FUNCTION# ====================================================================================================================
; Name...........: SelectRole
; Description ...: Seleziona il ruolo nella combo (default / SYSDBA / SYSOPER)
; ===============================================================================================================================
Func SelectRole($sRole)

	Local $iDown = 0

	Switch StringUpper(StringStripWS($sRole, 3))
		Case "SYSDBA"
			$iDown = 1
		Case "SYSOPER"
			$iDown = 2
		Case Else
			$iDown = 0 ; default
	EndSwitch

	If $iDown = 0 Then Return

	Send("!l") ; combo Role ; CHANGE_ME se l'acceleratore differisce
	Sleep($DELAY_SHORT)
	Send("{DOWN " & $iDown & "}")
	Sleep($DELAY_SHORT)
	Send("{ENTER}")
	Sleep($DELAY_SHORT)

	LogWrite("role selected: " & $sRole)

EndFunc   ;==>SelectRole

; #FUNCTION# ====================================================================================================================
; Name...........: Error
; Description ...: An exception handler - displays an error message and terminates the dispatcher
; Parameters ....: $ErrorMessage - Error message to display
; 				   $Code 		 - [Optional] Exit error code
; ===============================================================================================================================
Func Error($ErrorMessage, $Code = -1)

	; If the dispatcher utils DLL was already initialized, write an error log message and terminate the wrapper
	If (PSMGenericClient_IsInitialized()) Then
		LogWrite($ErrorMessage, True)
		PSMGenericClient_Term()
	EndIf

	Local $MessageFlags = BitOR(0, 16, 262144) ; 0=OK button, 16=Stop-sign icon, 262144=MsgBox has top-most attribute set

	MsgBox($MessageFlags, $ERROR_MESSAGE_TITLE, $ErrorMessage)

	; If the connection component was already invoked, terminate it
	If ($ConnectionClientPID <> 0) Then
		ProcessClose($ConnectionClientPID)
		$ConnectionClientPID = 0
	EndIf

	Exit $Code
EndFunc   ;==>Error

; #FUNCTION# ====================================================================================================================
; Name...........: LogWrite
; Description ...: Write a dispatcher log message to standard PSM log file
; Parameters ....: $sMessage - [IN] The message to write
;                  $LogLevel - [Optional] [IN] Defined if the message should be handled as an error message or as a trace messge
; Return values .: $PSM_ERROR_SUCCESS - Success, otherwise error - Use PSMGenericClient_PSMGetLastErrorString for details.
; ===============================================================================================================================
Func LogWrite($sMessage, $LogLevel = $LOG_LEVEL_TRACE)
	Return PSMGenericClient_LogWrite($LOG_MESSAGE_PREFIX & $sMessage, $LogLevel)
EndFunc   ;==>LogWrite
